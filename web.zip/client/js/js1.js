$(document).ready(function () {

       

$('input[name="daterange"]').daterangepicker();
		

    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
		
});